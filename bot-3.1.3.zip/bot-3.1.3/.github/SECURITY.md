# Security policy

## Supported versions

Release versions that will receive security updates.

| Version | Supported |
| ------- | --------- |
| 3.x     | ✅         |
| 2.x     | ❌         |
| 1.x     | ❌         |

## Reporting a vulnerability

If you find a vulnerability, please send an email to [contact@discordtickets.app](mailto:contact@discordtickets.app).
